<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Agro Bank</h1>

        <p class="lead">Xizmatlar.</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Ro'yhatdan o'tish</a></p>
    </div>

    <div class="body-content">

        s
    </div>
</div>
