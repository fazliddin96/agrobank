<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Bank haqida';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
       Agrobank mamlakatimizning barcha hududlarida o’zining muassasalariga ega bo’lib, Qoraqalpog’iston Respublikasi va 12 ta vilojat boshqarmasi, 178 ta tuman (shahar) filiali, 248 ta minibanki, 102 ta maxsus kassasi, 231 ta xalqaro pul o'tkazmalari shoxobchalari orqali 258 mingdan ortiq yuridik shaxslarga hamda 2,4 milliondan ortiq jismoniy shaxslarga sifatli zamonaviy bank xizmatlarini ko’rsatib kelmoqda. 

Agrobank o’z faoliyati davomida asosiy urg’uni iqtisodiyotning agrar sektorini moliyalashtirish, aholining bo’sh pul mablag’larini bank pul aylanmasiga jalb qilish, filiallar tarmog’i, xizmat turlari hamda mijozlari sonini ko’paytirish, bankning belgilangan beznes-rejasi va byudjetining asosiy parametrlarini bajarishga qaratgan.

Kichik biznesni qo’llab-quvvatlash uchun Islom xususiy sektorni rivojlantirish Assotsiatsiyasining 5 mln. AQSh dollari miqdorida kredit liniyasi bo'yicha loyihalarni moliyalashtirish amalga oshirildi.

Agrobank va Osiyo Taraqqiyot Banki o’rtasida 20,0 mln. AQSh dollari miqdoridan iborat bo’lgan «Kichik va mikromoliyalashni rivojlantirish. II bosqich» loyihasi bo’yicha kredit shartnomasi imzolangan. Ushbu loyihaning maqsadi respublikada mikromoliyalashtirishni yanada rivojlantirish hisoblanadi. Shuningdek, Agrobank Osiyo Taraqqiyot Bankining savdoni moliyalashni qo’llab-quvvatlash dasturiga kiritilgan va revol’ver kredit to’g’risida kelishuv imzolangan.

«VISA International» xalqaro to’lov tizimiga prinsipal a’zolikka o’tish bo’yicha qator ishlar amalga oshirildi. Protsesning markazini tashkil etish bilan bir qatorda chipli plastik kartalarni emissiya qilish yo’lga qo’yildi. 

Bank kichik biznesni rivojlantirish maqsadida KfV, YTTB, OTB va Xitoy Xalq Respublikasining Eksimbanki, Xalqaro Taraqqiyot va Tiklanish bankining (XTTB) kredit yo’nalishlarini jalb etgan.

Agrobankning xalqaro operatsiyalari xorijdagi va Respublika ichidagi 23 ta bankdagi vakillik hisob raqamlari orqali amalga oshiriladi.
Shuningdek, Agrobank S.W.I.F.T jahon banklararo moliyaviy telekommunikatsiyalar hamjamiyatiga a’zodir.

Agrobank Osiyo Tinch okeani Qishloq va qishloq xo’jaligini kreditlash Assotsiatsiyasi (APRAKA) hamda Qishloq xo’jaligi krediti Xalqaro Konfederatsiyasi (KIKA)ning teng huquqli a’zosi hisoblanadi. 2010 yilning iyun oyida Toshkentda Agrobank ishtirokida Osiyo-Tinch okeani mintaqasi Qishloq va qishloq xo’jaligini kreditlash assotsiatsiyasi Bosh Assambleyasining 17-yig’ilishi va Ijroiya qo’mitasining 58-majlisi o’tkazildi. Ushbu tadbirlar doirasida qishloq xo’jaligini kreditlashda kredit tavakkalchiligini boshqarish bo’yicha konferensiya bo’lib o’tdi. Bosh Assambleya qaroriga muvofiq 2010–2012 yillar davomida APRAKAga raislik qilish vazifasini bajarish Agrobankka topshirildi.
    </p>

    <code><?= __FILE__ ?></code>
</div>
