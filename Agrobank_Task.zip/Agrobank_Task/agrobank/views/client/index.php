<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ClientSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Clients';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="client-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Client', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <!-- <?php  echo $this->render('_search', ['model' => $searchModel]); ?> -->

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'ID',
            'Ism',
            'Familiya',
            'Yosh',
            //'Viloyat',
            [
                'attribute' => 'Viloyat',
                'filter'=>[
                      ''=>'Viloyatni tanlang',
                      'namangan'=>'Namangan',
                      'nukus'=>'Nukus',
                      'andijan'=>'Andijan',
                      'tashkent'=>'Tashkent',
                      'namangan'=>'Namangan',
                      'fergana'=>'Fergana',
                      'sirdaryo'=>'Sirdaryo',
                      'buxoro'=>'Buxoro',
                      'qashqadaryo'=>'Qashqadaryo',
                      'jizzax'=>'Jizzax',
                      'samarqand'=>'Samarqand'  
                ],
                'contentOptions'=>[
                    'width'=>'200px'
                ]
            ],
           // 'Xizmat',
            [
                'attribute' => 'Xizmat',
                'filter'=>[
                      ''=>'Hizmatni tanlang',
                      'kredit'=>'Kredit',
                      'kartalar'=>'Kartalar',
                      'deposit'=>'Deposit'  
                ],
                'contentOptions'=>[
                    'width'=>'200px'
                ]
            ],
             ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?> 

 
</div>
