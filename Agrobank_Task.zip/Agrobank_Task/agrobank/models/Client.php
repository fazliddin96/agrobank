<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "client".
 *
 * @property int $ID
 * @property string $Ism
 * @property string $Familiya
 * @property int $Yosh
 * @property string $Viloyat
 * @property string $Xizmat
 */
class Client extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'client';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Ism', 'Familiya', 'Yosh', 'Viloyat', 'Xizmat'], 'required'],
            [['Yosh'], 'integer'],
            [['Ism', 'Familiya'], 'string', 'max' => 15],
            [['Viloyat', 'Xizmat'], 'string', 'max' => 20],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'Ism' => 'Ism',
            'Familiya' => 'Familiya',
            'Yosh' => 'Yosh',
            'Viloyat' => 'Viloyat',
            'Xizmat' => 'Xizmat',
        ];
    }
}
