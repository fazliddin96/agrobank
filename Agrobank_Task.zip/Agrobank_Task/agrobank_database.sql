-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2019 at 10:49 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrobank`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `ID` int(11) NOT NULL,
  `Ism` varchar(15) NOT NULL,
  `Familiya` varchar(15) NOT NULL,
  `Yosh` int(2) NOT NULL,
  `Viloyat` varchar(20) NOT NULL,
  `Xizmat` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`ID`, `Ism`, `Familiya`, `Yosh`, `Viloyat`, `Xizmat`) VALUES
(1, 'Fazliddin', 'Kamoliddinov', 23, 'Namangan', 'kredit'),
(2, 'Elyor', 'Mirsaidov', 23, 'Tashkent', 'deposit'),
(3, 'Akmal', 'Mahkamov', 18, 'Tashkent', 'kredit'),
(4, 'Zayniddin', 'Kamoliddinov', 22, 'Farg''ona', 'deposit'),
(5, 'Zuhriddin', 'Kamoliddinov', 17, 'Andijon', 'deposit'),
(6, 'Elbek', 'Mamadaliyev', 45, 'Nukus', 'kredit'),
(7, 'Abdurahmon', 'Muhiddinov', 50, 'Samarqand', 'kredit'),
(8, 'Kamola', 'Sobitova', 21, 'Qashqadaryo', 'plastik kartalar'),
(9, 'Maxim', 'Kim', 32, 'Horazm', 'plastik kartalar'),
(10, 'Mahmud', 'Fozilov', 80, 'Surxondaryo', 'kredit'),
(11, 'Abdusoli', 'Ergashev', 22, 'Buxoro', 'deposit'),
(12, 'Saloxiddin', 'Jahonboyev', 42, 'Namangan', 'kredit'),
(13, 'Mahkam', 'Aliyev', 55, 'Farg''ona', 'deposit'),
(14, 'Maftuna', 'Abdullayeva', 27, 'Navoiy', 'plastik kartalar'),
(15, 'Qudrat', 'Kim', 39, 'Nukus', 'plastik kartalar'),
(19, 'Badir', 'Meliyev', 20, 'Nukus', 'kartalar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
